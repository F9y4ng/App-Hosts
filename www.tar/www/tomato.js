Array.prototype.find = function(b) {
	for (var c = 0; c < this.length; ++c) {
		if (this[c] == b) {
			return c
		}
	}
	return -1
};
Array.prototype.remove = function(b) {
	for (var c = 0; c < this.length; ++c) {
		if (this[c] == b) {
			this.splice(c, 1);
			return true
		}
	}
	return false
};
String.prototype.trim = function() {
	return this.replace(/^\s+/, "").replace(/\s+$/, "")
};
Number.prototype.pad = function(b) {
	var c = this.toString();
	while (c.length < b) {
		c = "0" + c
	}
	return c
};
Number.prototype.hex = function(b) {
	var d = "0123456789ABCDEF";
	var e = this;
	var c = "";
	do {
		c = d.charAt(e & 15) + c;
		e = e >>> 4
	} while ((--b > 0) || (e > 0));
	return c
};
var elem = {
	getOffset: function(c) {
		var b = {
			x: 0,
			y: 0
		};
		c = E(c);
		while (c.offsetParent) {
			b.x += c.offsetLeft;
			b.y += c.offsetTop;
			c = c.offsetParent
		}
		return b
	},
	addClass: function(g, d) {
		if ((g = E(g)) == null) {
			return
		}
		var b = g.className.split(/\s+/);
		var c = 0;
		for (var f = 1; f < arguments.length; ++f) {
			if (b.find(arguments[f]) == -1) {
				b.push(arguments[f]);
				c = 1
			}
		}
		if (c) {
			g.className = b.join(" ")
		}
	},
	removeClass: function(g, d) {
		if ((g = E(g)) == null) {
			return
		}
		var b = g.className.split(/\s+/);
		var c = 0;
		for (var f = 1; f < arguments.length; ++f) {
			c |= b.remove(arguments[f])
		}
		if (c) {
			g.className = b.join(" ")
		}
	},
	remove: function(b) {
		if ((b = E(b)) != null) {
			b.parentNode.removeChild(b)
		}
	},
	parentElem: function(c, b) {
		c = E(c);
		b = b.toUpperCase();
		while (c.parentNode) {
			c = c.parentNode;
			if (c.tagName == b) {
				return c
			}
		}
		return null
	},
	display: function() {
		var b = arguments[arguments.length - 1];
		for (var c = 0; c < arguments.length - 1; ++c) {
			E(arguments[c]).style.display = b ? "" : "none"
		}
	},
	isVisible: function(b) {
		b = E(b);
		while (b) {
			if ((b.style.visibility != "visible") || (b.style.display == "none")) {
				return false
			}
			b = b.parentNode
		}
		return true
	},
	setInnerHTML: function(c, b) {
		c = E(c);
		if (c.innerHTML != b) {
			c.innerHTML = b
		}
	}
};
var docu = {
	getViewSize: function() {
		if (window.innerHeight) {
			return {
				width: window.innerWidth,
				height: window.innerHeight
			}
		} else {
			if (document.documentElement && document.documentElement.clientHeight) {
				return {
					width: document.documentElement.clientWidth,
					height: document.documentElement.clientHeight
				}
			}
		}
		return {
			width: document.body.clientWidth,
			height: document.body.clientHeight
		}
	},
	getPageOffset: function() {
		if (typeof(window.pageYOffset) != "undefined") {
			return {
				x: window.pageXOffset,
				y: window.pageYOffset
			}
		} else {
			if ((document.documentElement) && (typeof(document.documentElement.scrollTop) != "undefined")) {
				return {
					x: document.documentElement.scrollLeft,
					y: document.documentElement.scrollTop
				}
			}
		}
		return {
			x: document.body.scrollLeft,
			y: document.body.scrollTop
		}
	}
};
var fields = {
	getAll: function(d) {
		var b = [];
		switch (d.tagName) {
		case "INPUT":
		case "SELECT":
			b.push(d);
			break;
		default:
			if (d.childNodes) {
				for (var c = 0; c < d.childNodes.length; ++c) {
					b = b.concat(fields.getAll(d.childNodes[c]))
				}
			}
		}
		return b
	},
	disableAll: function(f, g) {
		var c;
		if (f == null) {
			return false
		}
		if ((typeof(f.tagName) == "undefined") && (typeof(f) != "string")) {
			for (c = f.length - 1; c >= 0; --c) {
				f[c].disabled = g
			}
		} else {
			var b = this.getAll(E(f));
			for (var c = b.length - 1; c >= 0; --c) {
				b[c].disabled = g
			}
		}
	},
	radio: {
		selected: function(c) {
			for (var b = 0; b < c.length; ++b) {
				if (c[b].checked) {
					return c[b]
				}
			}
			return null
		},
		find: function(d, c) {
			for (var b = 0; b < d.length; ++b) {
				if (d[b].value == c) {
					return d[b]
				}
			}
			return null
		}
	}
};
var form = {
	submitHidden: function(g, c) {
		var d, b;
		d = document.createElement("FORM");
		d.action = g;
		d.method = "post";
		for (var h in c) {
			var j = document.createElement("INPUT");
			j.type = "hidden";
			j.name = h;
			j.value = c[h];
			d.appendChild(j)
		}
		b = document.getElementsByTagName("body")[0];
		d = b.appendChild(d);
		this.submit(d);
		b.removeChild(d)
	},
	submit: function(n, g, b) {
		var l, o, k, h, j, c, m, d;
		n = E(n);
		if (isLocal()) {
			this.dump(n, g, b);
			return
		}
		if (this.xhttp) {
			return
		}
		if ((m = E("save-button")) != null) {
			m.disabled = 1
		}
		if ((d = E("cancel-button")) != null) {
			d.disabled = 1
		}
		if ((!g) || (!useAjax())) {
			this.addId(n);
			if (b) {
				n.action = b
			}
			n.submit();
			return
		}
		o = ["_ajax=1"];
		j = 5;
		for (var h = 0; h < n.elements.length; ++h) {
			k = n.elements[h];
			if (typeof(k) == "undefined" || (typeof(k.name) == "undefined")) {
				continue
			}
			if ((k.disabled) || (k.name == "") || (k.name.substr(0, 2) == "f_")) {
				continue
			}
			if ((k.tagName == "INPUT") && ((k.type == "CHECKBOX") || (k.type == "RADIO")) && (!k.checked)) {
				continue
			}
			if (k.name == "_nextwait") {
				j = k.value * 1;
				if (isNaN(j)) {
					j = 5
				} else {
					j = Math.abs(j)
				}
			}
			o.push(escapeCGI(k.name) + "=" + escapeCGI(k.value))
		}
		if ((c = E("footer-msg")) != null) {
            c.innerHTML = "正在保存...";
			c.style.visibility = "visible"
		}
		this.xhttp = new XmlHttp();
		this.xhttp.onCompleted = function(f, e) {
			if (c) {
				if (f.match(/@msg:(.+)/)) {
					c.innerHTML = escapeHTML(RegExp.$1)
				} else {
                    c.innerHTML = "已保存"
				}
			}
			setTimeout(function() {
				if (m) {
					m.disabled = 0
				}
				if (d) {
					d.disabled = 0
				}
				if (c) {
					c.style.visibility = "hidden"
				}
				if (typeof(submit_complete) != "undefined") {
					submit_complete()
				}
			}, j * 1100);
			form.xhttp = null
		};
		this.xhttp.onError = function(e) {
			if (b) {
				n.action = b
			}
			n.submit()
		};
		this.xhttp.post(b ? b : n.action, o.join("&"))
	},
	addId: function(b) {
		var c;
		if (typeof(b._http_id) == "undefined") {
			c = document.createElement("INPUT");
			c.type = "hidden";
			c.name = "_http_id";
			c.value = nvram.http_id;
			b.appendChild(c)
		} else {
			b._http_id.value = nvram.http_id
		}
	},
	addIdAction: function(b) {
		if (b.action.indexOf("?") != -1) {
			b.action += "&_http_id=" + nvram.http_id
		} else {
			b.action += "?_http_id=" + nvram.http_id
		}
	},
	dump: function(b, d, c) {}
};
var ferror = {
	set: function(d, c, b) {
		if ((d = E(d)) == null) {
			return
		}
		d._error_msg = c;
		d._error_org = d.title;
		d.title = c;
		elem.addClass(d, "error");
		if (!b) {
			this.show(d)
		}
	},
	clear: function(b) {
		if ((b = E(b)) == null) {
			return
		}
		b.title = b._error_org || "";
		elem.removeClass(b, "error");
		b._error_msg = null;
		b._error_org = null
	},
	clearAll: function(c) {
		for (var b = 0; b < c.length; ++b) {
			this.clear(c[b])
		}
	},
	show: function(b) {
		if ((b = E(b)) == null) {
			return
		}
		if (!b._error_msg) {
			return
		}
		elem.addClass(b, "error-focused");
		b.focus();
		alert(b._error_msg);
		elem.removeClass(b, "error-focused")
	},
	ok: function(b) {
		if ((b = E(b)) == null) {
			return 0
		}
		return !b._error_msg
	}
};

function fixFile(b) {
	var c;
	if (((c = b.lastIndexOf("/")) > 0) || ((c = b.lastIndexOf("\\")) > 0)) {
		b = b.substring(c + 1, b.length)
	}
	return b
}
function _v_range(h, f, g, b, d) {
	if ((h = E(h)) == null) {
		return 0
	}
	var c = h.value;
	if ((!c.match(/^ *[-\+]?\d+ *$/)) || (c < g) || (c > b)) {
        ferror.set(h, "不正确的 " + d + ". 有效范围: " + g + "-" + b, f);
		return 0
	}
	h.value = c * 1;
	ferror.clear(h);
	return 1
}
function v_range(f, c, d, b) {
	return _v_range(f, c, d, b, "number")
}
function v_port(c, b) {
	return _v_range(c, b, 1, 65535, "port")
}
function v_octet(c, b) {
	return _v_range(c, b, 1, 254, "address")
}
function v_mins(h, f, g, c) {
	var d, b;
	if ((h = E(h)) == null) {
		return 0
	}
	if (h.value.match(/^\s*(.+?)([mhd])?\s*$/)) {
		b = 1;
		if (RegExp.$2 == "h") {
			b = 60
		} else {
			if (RegExp.$2 == "d") {
				b = 60 * 24
			}
		}
		d = Math.round(RegExp.$1 * b);
		if (!isNaN(d)) {
			h.value = d;
			return _v_range(h, f, g, c, "minutes")
		}
	}
    ferror.set(h, "输入的分钟数字不正确.", f);
	return 0
}
function v_macip(k, g, f, h, o) {
	var t, p, n, m, l, j;
	var r, q;
	q = h.split(".");
	r = q[0] + "." + q[1] + "." + q[2] + ".";
	if ((k = E(k)) == null) {
		return 0
	}
	t = k.value.replace(/\s+/g, "");
	if ((p = fixMAC(t)) != null) {
		if (isMAC0(p)) {
			if (f) {
				k.value = ""
			} else {
                ferror.set(k, "不正确的 MAC 或 IP 地址");
				return false
			}
		} else {
			k.value = p
		}
		ferror.clear(k);
		return true
	}
	p = t.split("-");
	if (p.length > 2) {
        ferror.set(k, "不正确的 IP 范围", g);
		return false
	}
	if (p[0].match(/^\d+$/)) {
		p[0] = r + p[0];
		if ((p.length == 2) && (p[1].match(/^\d+$/))) {
			p[1] = r + p[1]
		}
	} else {
		if ((p.length == 2) && (p[1].match(/^\d+$/))) {
			q = p[0].split(".");
			p[1] = q[0] + "." + q[1] + "." + q[2] + "." + p[1]
		}
	}
	for (j = 0; j < p.length; ++j) {
		n = p[j];
		n = fixIP(n);
		if (!n) {
            ferror.set(k, "不正确的 IP 地址", g);
			return false
		}
		if ((aton(n) & aton(o)) != (aton(h) & aton(o))) {
            ferror.set(k, "IP 地址 超出 LAN", g);
			return false
		}
		l = (n.split("."))[3];
		if (parseInt(l) <= parseInt(m)) {
            ferror.set(k, "不正确的 IP 范围", g);
			return false
		}
		p[j] = m = l
	}
	k.value = n.split(".")[0] + "." + n.split(".")[1] + "." + n.split(".")[2] + "." + p.join("-");
	return true
}
function fixIP(e, b) {
	var c, f, d;
	c = e;
	d = c.indexOf("<br>");
	if (d > 0) {
		c = c.slice(0, d)
	}
	c = c.split(".");
	if (c.length != 4) {
		return null
	}
	for (d = 0; d < 4; ++d) {
		f = c[d] * 1;
		if ((isNaN(f)) || (f < 0) || (f > 255)) {
			return null
		}
		c[d] = f
	}
	if ((b) && ((c[3] == 0) || (c[3] == 255))) {
		return null
	}
	return c.join(".")
}
function v_ip(d, c, b) {
	var f;
	if ((d = E(d)) == null) {
		return 0
	}
	f = fixIP(d.value, b);
	if (!f) {
        ferror.set(d, "不正确的 IP 地址", c);
		return false
	}
	d.value = f;
	ferror.clear(d);
	return true
}
function v_ipz(c, b) {
	if ((c = E(c)) == null) {
		return 0
	}
	if (c.value == "") {
		c.value = "0.0.0.0"
	}
	return v_ip(c, b)
}
function v_dns(d, b) {
	if ((d = E(d)) == null) {
		return 0
	}
	if (d.value == "") {
		d.value = "0.0.0.0"
	} else {
		var c = d.value.split(":");
		if (c.length == 1) {
			c.push(53)
		} else {
			if (c.length != 2) {
                ferror.set(d, "无效的 IP 地址或 端口", b);
				return false
			}
		}
		if ((c[0] = fixIP(c[0])) == null) {
            ferror.set(d, "不正确的 IP 地址", b);
			return false
		}
		if ((c[1] = fixPort(c[1], -1)) == -1) {
            ferror.set(d, "不正确的端口", b);
			return false
		}
		if (c[1] == 53) {
			d.value = c[0]
		} else {
			d.value = c.join(":")
		}
	}
	ferror.clear(d);
	return true
}
function aton(e) {
	var d, b, c;
	d = e.split(".");
	b = "";
	for (c = 0; c < 4; ++c) {
		b += (d[c] * 1).hex(2)
	}
	return parseInt(b, 16)
}
function ntoa(b) {
	return ((b >> 24) & 255) + "." + ((b >> 16) & 255) + "." + ((b >> 8) & 255) + "." + (b & 255)
}
function _v_iptip(f, d, c) {
	var n, m, j, g, k;
	var l, h;
	k = d;
	if (d.match(/^(.*)-(.*)$/)) {
		l = fixIP(RegExp.$1);
		h = fixIP(RegExp.$2);
		if ((l == null) || (h == null)) {
            ferror.set(f, k + " - 不正确的 IP 地址范围", c);
			return null
		}
		ferror.clear(f);
		if (aton(l) > aton(h)) {
			return h + "-" + l
		}
		return l + "-" + h
	}
	n = "";
	if (d.match(/^(.*)\/(.*)$/)) {
		d = RegExp.$1;
		h = RegExp.$2;
		n = h * 1;
		if (isNaN(n)) {
			n = fixIP(h);
			if ((n == null) || (!_v_netmask(n))) {
                ferror.set(f, k + " - 无效的子网掩码", c);
				return null
			}
		} else {
			if ((n < 0) || (n > 32)) {
                ferror.set(f, k + " - 无效的子网掩码", c);
				return null
			}
		}
	}
	d = fixIP(d);
	if (!d) {
        ferror.set(f, k + " - 无效的IP 地址", c);
		return null
	}
	ferror.clear(f);
	return d + ((n != "") ? ("/" + n) : "")
}
function v_iptip(g, c, f) {
	var b, d;
	if ((g = E(g)) == null) {
		return 0
	}
	b = g.value.split(",");
	if (f) {
		if (b.length > f) {
            ferror.set(g, "IP 地址输入太多", c);
			return 0
		}
	} else {
		if (b.length > 1) {
            ferror.set(g, "不正确的 IP 地址", c);
			return 0
		}
	}
	for (d = 0; d < b.length; ++d) {
		if ((b[d] = _v_iptip(g, b[d], c)) == null) {
			return 0
		}
	}
	g.value = b.join(", ");
	return 1
}
function _v_subnet(d, f, b) {
	var g, c;
	c = f;
	if (f.match(/^(.*)\/(.*)$/)) {
		f = RegExp.$1;
		g = RegExp.$2;
		if ((g < 0) || (g > 32)) {
            ferror.set(d, c + " - 无效的子网", b);
			return null
		}
	} else {
		ferror.set(d, c + " - invalid subnet", b);
		return null
	}
	ferror.clear(d);
	return f + ((g != "") ? ("/" + g) : "")
}
function v_subnet(c, b) {
	if ((_v_subnet(c, c.value, b)) == null) {
		return 0
	}
	return 1
}
function _v_domain(d, f, b) {
	var c;
	c = f.replace(/\s+/g, " ").trim();
	if (c.length > 0) {
		c = _v_hostname(d, c, 1, 1, 7, ".", true);
		if (c == null) {
            ferror.set(d, '无效的名称. 仅 "A-Z 0-9 . -" 被允许.', b);
			return null
		}
	}
	ferror.clear(d);
	return c
}
function v_domain(d, c) {
	var b;
	if ((d = E(d)) == null) {
		return 0
	}
	if ((b = _v_domain(d, d.value, c)) == null) {
		return 0
	}
	d.value = b;
	return 1
}
function ExpandIPv6Address(g) {
	var b, f, h, d, e, c;
	g = g.toLowerCase();
	if (!g.match(/^(::)?([a-f0-9]{1,4}::?){0,7}([a-f0-9]{1,4})(::)?$/)) {
		return null
	}
	b = g.split("::");
	switch (b.length) {
	case 1:
		if (b[0] == "") {
			return null
		}
		f = b[0].split(":");
		if (f.length != 8) {
			return null
		}
		g = f.join(":");
		break;
	case 2:
		f = b[0].split(":");
		c = b[1].split(":");
		h = 8 - f.length - c.length;
		for (d = 0; d < 2; d++) {
			if (b[d] == "") {
				h++
			}
		}
		if (h < 0) {
			return null
		}
		e = "";
		while (h-- > 0) {
			e += ":0"
		}
		g = f.join(":") + e + ":" + c.join(":");
		g = g.replace(/^:/, "").replace(/:$/, "");
		break;
	default:
		return null
	}
	g = g.replace(/([a-f0-9]{1,4})/ig, "000$1");
	g = g.replace(/0{0,3}([a-f0-9]{4})/ig, "$1");
	return g
}
function CompressIPv6Address(d) {
	var b, c;
	d = ExpandIPv6Address(d);
	if (!d) {
		return null
	}
	d = d.replace(/(^|:)0{1,3}/g, "$1");
	d = d.replace(/(:0)+$/, "::");
	d = d.replace(/(?:(?:^|:)0){2,}(?!.*(?:::|(?::0){3,}))/, ":");
	return d
}
function ZeroIPv6PrefixBits(g, f) {
	var e, j, d, h;
	g = ExpandIPv6Address(g);
	g = g.replace(/:/g, "");
	h = Math.floor(f / 4);
	d = 32 - Math.ceil(f / 4);
	e = f % 4;
	if (e != 0) {
		j = (parseInt(g.charAt(h), 16) & (15 << 4 - e)).toString(16)
	} else {
		j = ""
	}
	g = g.substring(0, h) + j + Array((d % 4) + 1).join("0") + (d >= 4 ? "::" : "");
	g = g.replace(/([a-f0-9]{4})(?=[a-f0-9])/g, "$1:");
	g = g.replace(/(^|:)0{1,3}/g, "$1");
	return g
}
function ipv6ton(e) {
	var d, b, c;
	e = ExpandIPv6Address(e);
	if (!e) {
		return 0
	}
	d = e.split(":");
	b = "";
	for (c = 0; c < 8; ++c) {
		b += (("0x" + d[c]) * 1).hex(4)
	}
	return parseInt(b, 16)
}
function _v_ipv6_addr(j, k, h, f) {
	var g;
	var d, c;
	g = k;
	if ((h) && k.match(/^(.*)-(.*)$/)) {
		d = RegExp.$1;
		c = RegExp.$2;
		d = CompressIPv6Address(d);
		c = CompressIPv6Address(c);
		if ((d == null) || (c == null)) {
            ferror.set(j, g + " - 无效的 IPv6 地址范围", f);
			return null
		}
		ferror.clear(j);
		if (ipv6ton(d) > ipv6ton(c)) {
			return c + "-" + d
		}
		return d + "-" + c
	}
	if ((h) && k.match(/^([A-Fa-f0-9:]+)\/(\d+)$/)) {
		d = RegExp.$1;
		c = parseInt(RegExp.$2, 10);
		d = ExpandIPv6Address(d);
		if ((d == null) || (c == null)) {
            ferror.set(j, g + " - 无效的 IPv6 地址", f);
			return null
		}
		if (c < 0 || c > 128) {
            ferror.set(j, g + " - IPv6地址上的CIDR标记无效", f);
			return null
		}
		ferror.clear(j);
		k = ZeroIPv6PrefixBits(d, c);
		return k + "/" + c.toString(10)
	}
	k = CompressIPv6Address(g);
	if (!k) {
        ferror.set(j, g + " - 无效的 IPv6 地址", f);
		return null
	}
	ferror.clear(j);
	return k
}
function v_ipv6_addr(c, b) {
	if ((c = E(c)) == null) {
		return 0
	}
	ip = _v_ipv6_addr(c, c.value, false, b);
	if (ip) {
		c.value = ip
	}
	return (ip != null)
}
function fixPort(c, b) {
	if (b == null) {
		b = -1
	}
	if (c == null) {
		return b
	}
	c *= 1;
	if ((isNaN(c) || (c < 1) || (c > 65535) || (("" + c).indexOf(".") != -1))) {
		return b
	}
	return c
}
function _v_portrange(f, d, c) {
	if (c.match(/^(.*)[-:](.*)$/)) {
		var b = RegExp.$1;
		var g = RegExp.$2;
		b = fixPort(b, -1);
		g = fixPort(g, -1);
		if ((b == -1) || (g == -1)) {
            ferror.set(f, "不正确的端口范围: " + c, d);
			return null
		}
		if (b > g) {
			c = b;
			b = g;
			g = c
		}
		ferror.clear(f);
		if (b == g) {
			return b
		}
		return b + "-" + g
	}
	c = fixPort(c, -1);
	if (c == -1) {
        ferror.set(f, "不正确的端口", d);
		return null
	}
	ferror.clear(f);
	return c
}
function v_portrange(d, c) {
	var b;
	if ((d = E(d)) == null) {
		return 0
	}
	b = _v_portrange(d, c, d.value);
	if (b == null) {
		return 0
	}
	d.value = b;
	return 1
}
function v_iptport(h, d) {
	var b, f, c, g;
	if ((h = E(h)) == null) {
		return 0
	}
	b = h.value.split(/[,\.]/);
	if (b.length == 0) {
        ferror.set(h, "需要指定端口列表或端口范围.", d);
		return 0
	}
	if (b.length > 10) {
        ferror.set(h, "您输入的端口列表或端口范围超出10个，请减少一些端口.", d);
		return 0
	}
	g = [];
	for (f = 0; f < b.length; ++f) {
		c = _v_portrange(h, d, b[f]);
		if (c == null) {
			return 0
		}
		g.push(c)
	}
	h.value = g.join(",");
	ferror.clear(h);
	return 1
}
function _v_netmask(b) {
	var c = aton(b) ^ 4294967295;
	return (((c + 1) & c) == 0)
}
function v_netmask(f, d) {
	var g, c;
	if ((f = E(f)) == null) {
		return 0
	}
	g = fixIP(f.value);
	if (g) {
		if (_v_netmask(g)) {
			f.value = g;
			ferror.clear(f);
			return 1
		}
	} else {
		if (f.value.match(/^\s*\/\s*(\d+)\s*$/)) {
			c = RegExp.$1 * 1;
			if ((c >= 1) && (c <= 32)) {
				if (c == 32) {
					g = 4294967295
				} else {
					g = (4294967295 >>> c) ^ 4294967295
				}
				f.value = (g >>> 24) + "." + ((g >>> 16) & 255) + "." + ((g >>> 8) & 255) + "." + (g & 255);
				ferror.clear(f);
				return 1
			}
		}
	}
    ferror.set(f, "子网掩码不正确", d);
	return 0
}
function fixMAC(d) {
	var c, b;
	d = d.replace(/\s+/g, "").toUpperCase();
	if (d.length == 0) {
		d = [0, 0, 0, 0, 0, 0]
	} else {
		if (d.length == 12) {
			d = d.match(/../g)
		} else {
			d = d.split(/[:\-]/);
			if (d.length != 6) {
				return null
			}
		}
	}
	for (b = 0; b < 6; ++b) {
		c = "" + d[b];
		if (c.search(/^[0-9A-F]+$/) == -1) {
			return null
		}
		if ((c = parseInt(c, 16)) > 255) {
			return null
		}
		d[b] = c.hex(2)
	}
	return d.join(":")
}
function v_mac(c, b) {
	var d;
	if ((c = E(c)) == null) {
		return 0
	}
	d = fixMAC(c.value);
	if ((!d) || (isMAC0(d))) {
        ferror.set(c, "不正确的 MAC 地址", b);
		return 0
	}
	c.value = d;
	ferror.clear(c);
	return 1
}
function v_macz(c, b) {
	var d;
	if ((c = E(c)) == null) {
		return 0
	}
	d = fixMAC(c.value);
	if (!d) {
        ferror.set(c, "不正确的 MAC 地址", b);
		return false
	}
	c.value = d;
	ferror.clear(c);
	return true
}
function v_length(g, c, d, b) {
	var f, h;
	if ((g = E(g)) == null) {
		return 0
	}
	f = g.value.trim();
	h = f.length;
	if (d == undefined) {
		d = 1
	}
	if (h < d) {
        ferror.set(g, "不正确的长度. 请至少输入 " + d + " 个字符" + (d == 1 ? ".": "s."), c);
		return 0
	}
	b = b || g.maxlength;
	if (h > b) {
        ferror.set(g, "不正确的长度. 请缩短长度少于 " + b + " 个字符.", c);
		return 0
	}
	g.value = f;
	ferror.clear(g);
	return 1
}
function _v_iptaddr(k, f, j, d, b) {
	var c, h, g;
	if ((k = E(k)) == null) {
		return 0
	}
	c = k.value.split(",");
	if (j) {
		if (c.length > j) {
            ferror.set(k, "IP地址过多", f);
			return 0
		}
	} else {
		if (c.length > 1) {
            ferror.set(k, "无效的域或IP地址", f);
			return 0
		}
	}
	for (g = 0; g < c.length; ++g) {
		if ((h = _v_domain(k, c[g], 1)) == null) {
			if ((!b) && (!d)) {
				if (!f) {
					ferror.show(k)
				}
				return 0
			}
			if ((!b) || ((h = _v_ipv6_addr(k, c[g], 1, 1)) == null)) {
				if (!d) {
					if (!f) {
						ferror.show(k)
					}
					return 0
				}
				if ((h = _v_iptip(k, c[g], 1)) == null) {
                    ferror.set(k, k._error_msg + ", 或无效的域", f);
					return 0
				}
			}
		}
		c[g] = h
	}
	k.value = c.join(", ");
	ferror.clear(k);
	return 1
}
function v_iptaddr(d, b, c) {
	return _v_iptaddr(d, b, c, 1, 0)
}
function _v_hostname(k, g, d, l, j, b, c) {
	var o;
	var m, f;
	var n;
	m = (typeof(b) == "undefined") ? g.split(/\s+/) : g.split(b);
	if (j) {
		if (m.length > j) {
            ferror.set(k, "主机名过多.", d);
			return null
		}
	} else {
		if (m.length > 1) {
            ferror.set(k, "无效的主机名.", d);
			return null
		}
	}
	n = /^[a-zA-Z0-9](([a-zA-Z0-9\-]{0,61})[a-zA-Z0-9]){0,1}$/;
	for (f = 0; f < m.length; ++f) {
		o = m[f].replace(/_+/g, "-").replace(/\s+/g, "-");
		if (o.length > 0) {
			if (c && f == m.length - 1) {
				n = /^[a-zA-Z0-9](([a-zA-Z0-9\-]{0,61})[a-zA-Z0-9]){0,1}(\/\d{1,3})?$/
			}
			if (o.search(n) == -1 || o.search(/^\d+$/) != -1) {
                ferror.set(k, '无效的主机名. 仅 "A-Z 0-9" 和 "-" 被允许 (最多63个字符).', d);
				return null
			}
		} else {
			if (l) {
                ferror.set(k, "无效的主机名.", d);
				return null
			}
		}
		m[f] = o
	}
	ferror.clear(k);
	return m.join((typeof(b) == "undefined") ? " " : b)
}
function v_hostname(f, c, d, g) {
	var b;
	if ((f = E(f)) == null) {
		return 0
	}
	b = _v_hostname(f, f.value, c, 0, d, g, false);
	if (b == null) {
		return 0
	}
	f.value = b;
	return 1
}
function v_nodelim(f, c, b, d) {
	if ((f = E(f)) == null) {
		return 0
	}
	f.value = f.value.trim();
	if (f.value.indexOf("<") != -1 || (d && f.value.indexOf(">") != -1)) {
        ferror.set(f, "不正确的 " + b + ': "<" ' + (d ? '或 ">" 是': "是") + " 不允许的.", c);
		return 0
	}
	ferror.clear(f);
	return 1
}
function v_path(c, b, d) {
	if ((c = E(c)) == null) {
		return 0
	}
	if (d && !v_length(c, b, 1)) {
		return 0
	}
	if (!d && c.value.trim().length == 0) {
		ferror.clear(c);
		return 1
	}
	if (c.value.substr(0, 1) != "/") {
        ferror.set(c, "请以 / (斜杠) 作为根目录的开始.", b);
		return 0
	}
	ferror.clear(c);
	return 1
}
function isMAC0(b) {
	return (b == "00:00:00:00:00:00")
}
function cmpIP(d, c) {
	if ((d = fixIP(d)) == null) {
		d = "255.255.255.255"
	}
	if ((c = fixIP(c)) == null) {
		c = "255.255.255.255"
	}
	return aton(d) - aton(c)
}
function cmpText(d, c) {
	if (d == "") {
		d = "ÿ"
	}
	if (c == "") {
		c = "ÿ"
	}
	return (d < c) ? -1 : ((d > c) ? 1 : 0)
}
function cmpInt(d, c) {
	d = parseInt(d, 10);
	c = parseInt(c, 10);
	return ((isNaN(d)) ? -2147483647 : d) - ((isNaN(c)) ? -2147483647 : c)
}
function cmpFloat(d, c) {
	d = parseFloat(d);
	c = parseFloat(c);
	return ((isNaN(d)) ? -Number.MAX_VALUE : d) - ((isNaN(c)) ? -Number.MAX_VALUE : c)
}
function cmpDate(d, c) {
	return c.getTime() - d.getTime()
}
function TGO(b) {
	return elem.parentElem(b, "TABLE").gridObj
}
function tgHideIcons() {
	var b;
	while ((b = document.getElementById("table-row-panel")) != null) {
		b.parentNode.removeChild(b)
	}
}
function TomatoGrid(c, d, e, b) {
	this.init(c, d, e, b);
	return this
}
TomatoGrid.prototype = {
	init: function(c, d, e, b) {
		if (c) {
			this.tb = E(c);
			this.tb.gridObj = this
		} else {
			this.tb = null
		}
		if (!d) {
			d = ""
		}
		this.header = null;
		this.footer = null;
		this.editor = null;
		this.canSort = d.indexOf("sort") != -1;
		this.canMove = d.indexOf("move") != -1;
		this.maxAdd = e || 500;
		this.canEdit = (b != null);
		this.canDelete = this.canEdit || (d.indexOf("delete") != -1);
		this.editorFields = b;
		this.sortColumn = -1;
		this.sortAscending = true
	},
	_insert: function(b, l, d, g) {
		var j, e, h;
		var f, k;
		j = this.tb.insertRow(b);
		for (f = 0; f < l.length; ++f) {
			h = l[f];
			if (typeof(h) == "string") {
				e = j.insertCell(f);
				e.className = ((g === true) ? "header " : "") + "co" + (f + 1);
				if (d) {
					e.appendChild(document.createTextNode(h))
				} else {
					e.innerHTML = h
				}
			} else {
				j.appendChild(h)
			}
		}
		return j
	},
	headerClick: function(b) {
		if (this.canSort) {
			this.sort(b.cellN)
		}
	},
	headerSet: function(c, b) {
		var f, d;
		elem.remove(this.header);
		this.header = f = this._insert(0, c, b, true);
		for (d = 0; d < f.cells.length; ++d) {
			f.cells[d].cellN = d;
			f.cells[d].onclick = function() {
				return TGO(this).headerClick(this)
			}
		}
		return f
	},
	footerClick: function(b) {},
	footerSet: function(c, b) {
		var f, d;
		elem.remove(this.footer);
		this.footer = f = this._insert(-1, c, b);
		f.className = "bold controls";
		for (d = 0; d < f.cells.length; ++d) {
			f.cells[d].cellN = d;
			f.cells[d].onclick = function() {
				TGO(this).footerClick(this)
			}
		}
		return f
	},
	rpUp: function(c) {
		var b;
		c = PR(c);
		TGO(c).moving = null;
		b = c.previousSibling;
		if (b == this.header) {
			return
		}
		c.parentNode.removeChild(c);
		b.parentNode.insertBefore(c, b);
		this.recolor();
		this.rpHide()
	},
	rpDn: function(c) {
		var b;
		c = PR(c);
		TGO(c).moving = null;
		b = c.nextSibling;
		if (b == this.footer) {
			return
		}
		c.parentNode.removeChild(c);
		b.parentNode.insertBefore(c, b.nextSibling);
		this.recolor();
		this.rpHide()
	},
	rpMo: function(b, d) {
		var c;
		d = PR(d);
		c = TGO(d);
		if (c.moving == d) {
			c.moving = null;
			this.rpHide();
			return
		}
		c.moving = d;
		b.style.border = "1px dotted red"
	},
	rpDel: function(b) {
		b = PR(b);
		TGO(b).moving = null;
		b.parentNode.removeChild(b);
		this.recolor();
		this.rpHide()
	},
	rpMouIn: function(c) {
		var h, b, g, f, d, j;
		if ((c = checkEvent(c)) == null || c.target.nodeName == "A" || c.target.nodeName == "I") {
			return
		}
		f = TGO(c.target);
		if (f.isEditing()) {
			return
		}
		if (f.moving) {
			return
		}
		if (c.target.id != "table-row-panel") {
			f.rpHide()
		}
		h = document.createElement("div");
		h.tgo = f;
		h.ref = c.target;
		h.setAttribute("id", "table-row-panel");
		j = 0;
		d = "";
		if (f.canMove) {
            d = '<a class="move-up-row" href="#" onclick="this.parentNode.tgo.rpUp(this.parentNode.ref); return false;" title="上移"><i class="icon-chevron-up"></i></a> <a class="move-down-row" href="#" onclick="this.parentNode.tgo.rpDn(this.parentNode.ref); return false;" title="下移"><i class="icon-chevron-down"></i></a> <a class="move-row" href="#" onclick="this.parentNode.tgo.rpMo(this,this.parentNode.ref); return false;" title="移动"><i class="icon-move"></i></a> ';
			j += 3
		}
		if (f.canDelete) {
            d += '<a class="delete-row" href="#" onclick="this.parentNode.tgo.rpDel(this.parentNode.ref); return false;" title="删除"><i class="icon-cancel"></i></a>';
			++j
		}
		b = PR(c.target);
		b = b.cells[b.cells.length - 1];
		g = elem.getOffset(b);
		j *= 18;
		h.innerHTML = d;
		this.appendChild(h)
	},
	rpHide: tgHideIcons,
	onClick: function(b) {
		if (this.canEdit) {
			if (this.moving) {
				var e = this.moving.parentNode;
				var d = PR(b);
				if (this.moving != d) {
					var c = this.moving.rowIndex > d.rowIndex;
					e.removeChild(this.moving);
					if (c) {
						e.insertBefore(this.moving, d)
					} else {
						e.insertBefore(this.moving, d.nextSibling)
					}
					this.recolor()
				}
				this.moving = null;
				this.rpHide();
				return
			}
			this.edit(b)
		}
	},
	insert: function(c, g, d, b) {
		var h, f;
		if ((this.footer) && (c == -1)) {
			c = this.footer.rowIndex
		}
		h = this._insert(c, d, b);
		h.className = (h.rowIndex & 1) ? "even" : "odd";
		for (f = 0; f < h.cells.length; ++f) {
			h.cells[f].onclick = function() {
				return TGO(this).onClick(this)
			}
		}
		h._data = g;
		h.getRowData = function() {
			return this._data
		};
		h.setRowData = function(e) {
			this._data = e
		};
		if ((this.canMove) || (this.canEdit) || (this.canDelete)) {
			h.onmouseover = this.rpMouIn;
			h.onmouseout = this.rpMouOut;
			if (this.canEdit) {
                h.title = "点击此处进行编辑"
			}
			$(h).css("cursor", "text")
		}
		return h
	},
	insertData: function(b, c) {
		return this.insert(b, c, this.dataToView(c), false)
	},
	dataToView: function(h) {
		var c = [];
		for (var d = 0; d < h.length; ++d) {
			var e = escapeHTML("" + h[d]);
			if (this.editorFields && this.editorFields.length > d) {
				var b = this.editorFields[d].multi;
				if (!b) {
					b = [this.editorFields[d]]
				}
				var g = (b && b.length > 0 ? b[0] : null);
				if (g && g.type == "password") {
					if (!g.peekaboo || get_config("web_pb", "1") != "0") {
						e = e.replace(/./g, "&#x25CF;")
					}
				}
			}
			c.push(e)
		}
		return c
	},
	dataToFieldValues: function(b) {
		return b
	},
	fieldValuesToData: function(f) {
		var d, b, c;
		c = [];
		d = fields.getAll(f);
		for (b = 0; b < d.length; ++b) {
			c.push(d[b].value)
		}
		return c
	},
	edit: function(b) {
		var f, j, g, h;
		if (this.isEditing()) {
			return
		}
		f = PR(b);
		f.style.display = "none";
		elem.removeClass(f, "hover");
		this.source = f;
		j = this.createEditor("edit", f.rowIndex, f);
		j.className = "editor";
		this.editor = j;
		h = j.cells[b.cellIndex || 0];
		g = h.getElementsByTagName("input");
		if ((g) && (g.length > 0)) {
			try {
				g[0].focus()
			} catch (d) {}
		}
		this.controls = this.createControls("edit", f.rowIndex);
		this.disableNewEditor(true);
		this.rpHide();
		this.verifyFields(this.editor, true)
	},
	createEditor: function(h, t, b) {
		var u;
		if (h == "edit") {
			u = this.dataToFieldValues(b.getRowData())
		}
		var w = this.tb.insertRow(t);
		w.className = "editor";
		var q = " onkeypress=\"return TGO(this).onKey('" + h + "', event)\" onchange=\"TGO(this).onChange('" + h + "', this)\"";
		var l = 0;
		for (var o = 0; o < this.editorFields.length; ++o) {
			var v = "";
			var n = this.editorFields[o].multi;
			if (!n) {
				n = [this.editorFields[o]]
			}
			for (var g = 0; g < n.length; ++g) {
				var p = n[g];
				if (p.prefix) {
					v += p.prefix
				}
				var m = ' class="fi' + (l + 1) + " " + (p["class"] ? p["class"] : "") + '" ' + (p.attrib || "");
				var d = (this.tb ? ("_" + this.tb + "_" + (l + 1)) : null);
				if (d) {
					m += ' id="' + d + '"'
				}
				switch (p.type) {
				case "password":
					if (p.peekaboo) {
						switch (get_config("web_pb", "1")) {
						case "0":
							p.type = "text";
						case "2":
							p.peekaboo = 0;
							break
						}
					}
					m += ' autocomplete="off"';
					if (p.peekaboo && d) {
						m += " onfocus='peekaboo(\"" + d + "\",1)'"
					}
				case "text":
					v += '<input type="' + p.type + '" maxlength=' + p.maxlen + q + m;
					if (h == "edit") {
						v += ' value="' + escapeHTML("" + u[l]) + '">'
					} else {
						v += ">"
					}
					break;
				case "select":
					v += "<select" + q + m + ">";
					for (var e = 0; e < p.options.length; ++e) {
						a = p.options[e];
						if (h == "edit") {
							v += '<option value="' + a[0] + '"' + ((a[0] == u[l]) ? " selected>" : ">") + a[1] + "</option>"
						} else {
							v += '<option value="' + a[0] + '">' + a[1] + "</option>"
						}
					}
					v += "</select>";
					break;
				case "checkbox":
					v += '<div class="checkbox c-checkbox"><label><input type="checkbox"' + q + m;
					if ((h == "edit") && (u[l])) {
						v += " checked"
					}
					v += "><span></span> </label></div>";
					break;
				case "textarea":
					if (h == "edit") {
						document.getElementById(p.proxy).value = u[l]
					}
					break;
				default:
					v += p.custom.replace(/\$which\$/g, h)
				}
				if (p.suffix) {
					v += p.suffix
				}++l
			}
			var r = w.insertCell(o);
			r.innerHTML = v;
			if (this.editorFields[o].vtop) {
				r.vAlign = "top";
				r.style.verticalAlign = "top"
			}
		}
		return w
	},
	createControls: function(d, f) {
		var b, e;
		b = this.tb.insertRow(f);
		b.className = "controls";
		e = b.insertCell(0);
		e.colSpan = this.header.cells.length;
		if (d == "edit") {
            e.innerHTML = '<button type="button" class="btn btn-danger" value="Delete" onclick="TGO(this).onDelete()">删除 <i class="icon-cancel"></i></button> <button type="button" class="btn" value="Cancel" onclick="TGO(this).onCancel()">取消 <i class="icon-disable"></i></button> <button type="button" class="btn btn-primary" value="OK" onclick="TGO(this).onOK()">确认 <i class="icon-check"></i></button>'
		} else {
            e.innerHTML = '<button type="button" class="btn btn-danger" value="添加" onclick="TGO(this).onAdd()">添加 <i class="icon-plus"></i></button>'
		}
		return b
	},
	removeEditor: function() {
		if (this.editor) {
			elem.remove(this.editor);
			this.editor = null
		}
		if (this.controls) {
			elem.remove(this.controls);
			this.controls = null
		}
	},
	showSource: function() {
		if (this.source) {
			this.source.style.display = "";
			this.source = null
		}
	},
	onChange: function(c, b) {
		return this.verifyFields((c == "new") ? this.newEditor : this.editor, true)
	},
	onKey: function(c, b) {
		switch (b.keyCode) {
		case 27:
			if (c == "edit") {
				this.onCancel()
			}
			return false;
		case 13:
			if (((b.srcElement) && (b.srcElement.tagName == "SELECT")) || ((b.target) && (b.target.tagName == "SELECT"))) {
				return true
			}
			if (c == "edit") {
				this.onOK()
			} else {
				this.onAdd()
			}
			return false
		}
		return true
	},
	onDelete: function() {
		this.removeEditor();
		elem.remove(this.source);
		this.source = null;
		this.disableNewEditor(false)
	},
	onCancel: function() {
		this.removeEditor();
		this.showSource();
		this.disableNewEditor(false)
	},
	onOK: function() {
		var c, d, b;
		if (!this.verifyFields(this.editor, false)) {
			return
		}
		d = this.fieldValuesToData(this.editor);
		b = this.dataToView(d);
		this.source.setRowData(d);
		for (c = 0; c < this.source.cells.length; ++c) {
			this.source.cells[c].innerHTML = b[c]
		}
		this.removeEditor();
		this.showSource();
		this.disableNewEditor(false)
	},
	onAdd: function() {
		var b;
		this.moving = null;
		this.rpHide();
		if (!this.verifyFields(this.newEditor, false)) {
			return
		}
		b = this.fieldValuesToData(this.newEditor);
		this.insertData(-1, b);
		this.disableNewEditor(false);
		this.resetNewEditor()
	},
	verifyFields: function(c, b) {
		return true
	},
	showNewEditor: function() {
		var b;
		b = this.createEditor("new", -1, null);
		this.footer = this.newEditor = b;
		b = this.createControls("new", -1);
		this.newControls = b;
		this.disableNewEditor(false)
	},
	disableNewEditor: function(b) {
		if (this.getDataCount() >= this.maxAdd) {
			b = true
		}
		if (this.newEditor) {
			fields.disableAll(this.newEditor, b)
		}
		if (this.newControls) {
			fields.disableAll(this.newControls, b)
		}
	},
	resetNewEditor: function() {
		var b, d;
		d = fields.getAll(this.newEditor);
		ferror.clearAll(d);
		for (b = 0; b < d.length; ++b) {
			var c = d[b];
			if (c.selectedIndex) {
				c.selectedIndex = 0
			} else {
				c.value = ""
			}
		}
		try {
			if (d.length) {
				d[0].focus()
			}
		} catch (g) {}
	},
	getDataCount: function() {
		var b;
		b = this.tb.rows.length;
		if (this.footer) {
			b = this.footer.rowIndex
		}
		if (this.header) {
			b -= this.header.rowIndex + 1
		}
		return b
	},
	sortCompare: function(d, c) {
		var g = TGO(d);
		var e = g.sortColumn;
		var f = cmpText(d.cells[e].innerHTML, c.cells[e].innerHTML);
		return g.sortAscending ? f : -f
	},
	sort: function(b) {
		if (this.editor) {
			return
		}
		if (this.sortColumn >= 0) {
			$(this.header.cells[this.sortColumn]).find("i").remove()
		}
		if (b == this.sortColumn) {
			this.sortAscending = !this.sortAscending
		} else {
			this.sortAscending = true;
			this.sortColumn = b
		}
		$(this.header.cells[b]).append(this.sortAscending ? '<i class="icon-chevron-up icon-sort"></i>' : '<i class="icon-chevron-down icon-sort"></i>');
		this.resort()
	},
	resort: function() {
		if ((this.sortColumn < 0) || (this.getDataCount() == 0) || (this.editor)) {
			return
		}
		var k = this.header.parentNode;
		var c = [];
		var f, d, b, h, k;
		var g;
		this.moving = null;
		g = this.header ? this.header.rowIndex + 1 : 0;
		b = this.footer ? this.footer.rowIndex : this.tb.rows.length;
		for (f = g; f < b; ++f) {
			c.push(k.rows[f])
		}
		c.sort(THIS(this, this.sortCompare));
		this.removeAllData();
		d = g;
		for (f = 0; f < c.length; ++f) {
			h = k.insertBefore(c[f], this.footer);
			h.className = (d & 1) ? "even" : "odd";
			++d
		}
	},
	recolor: function() {
		var b, c, d;
		b = this.header ? this.header.rowIndex + 1 : 0;
		c = this.footer ? this.footer.rowIndex : this.tb.rows.length;
		for (; b < c; ++b) {
			d = this.tb.rows[b];
			d.className = (d.rowIndex & 1) ? "even" : "odd"
		}
	},
	removeAllData: function() {
		var b, c;
		b = this.header ? this.header.rowIndex + 1 : 0;
		c = (this.footer ? this.footer.rowIndex : this.tb.rows.length) - b;
		while (c-- > 0) {
			elem.remove(this.tb.rows[b])
		}
	},
	getAllData: function() {
		var c, b, e, d;
		e = [];
		b = this.footer ? this.footer.rowIndex : this.tb.rows.length;
		for (c = this.header ? this.header.rowIndex + 1 : 0; c < b; ++c) {
			d = this.tb.rows[c];
			if ((d.style.display != "none") && (d._data)) {
				e.push(d._data)
			}
		}
		return e
	},
	isEditing: function() {
		return (this.editor != null)
	}
};

function xmlHttpObj() {
	var b;
	try {
		b = new XMLHttpRequest();
		if (b) {
			return b
		}
	} catch (c) {}
	try {
		b = new ActiveXObject("Microsoft.XMLHTTP");
		if (b) {
			return b
		}
	} catch (c) {}
	return null
}
var _useAjax = -1;
var _holdAjax = null;

function useAjax() {
	if (_useAjax == -1) {
		_useAjax = ((_holdAjax = xmlHttpObj()) != null)
	}
	return _useAjax
}
function XmlHttp() {
	if ((!useAjax()) || ((this.xob = xmlHttpObj()) == null)) {
		return null
	}
	return this
}
XmlHttp.prototype = {
	addId: function(b) {
		if (b) {
			b += "&"
		} else {
			b = ""
		}
		b += "_http_id=" + escapeCGI(nvram.http_id);
		return b
	},
	get: function(b, d) {
		try {
			d = this.addId(d);
			b += "?" + d;
			this.xob.onreadystatechange = THIS(this, this.onReadyStateChange);
			this.xob.open("GET", b, true);
			this.xob.send(null)
		} catch (c) {
			this.onError(c)
		}
	},
	post: function(b, d) {
		try {
			d = this.addId(d);
			this.xob.onreadystatechange = THIS(this, this.onReadyStateChange);
			this.xob.open("POST", b, true);
			this.xob.send(d)
		} catch (c) {
			this.onError(c)
		}
	},
	abort: function() {
		try {
			this.xob.onreadystatechange = function() {};
			this.xob.abort()
		} catch (b) {}
	},
	onReadyStateChange: function() {
		try {
			if (typeof(E) == "undefined") {
				return
			}
			if (this.xob.readyState == 4) {
				if (this.xob.status == 200) {
					this.onCompleted(this.xob.responseText, this.xob.responseXML)
				} else {
					this.onError("" + (this.xob.status || "unknown"))
				}
			}
		} catch (b) {
			this.onError(b)
		}
	},
	onCompleted: function(c, b) {},
	onError: function(b) {}
};

function TomatoTimer(c, b) {
	this.tid = null;
	this.onTimer = c;
	if (b) {
		this.start(b)
	}
	return this
}
TomatoTimer.prototype = {
	start: function(b) {
		this.stop();
		this.tid = setTimeout(THIS(this, this._onTimer), b)
	},
	stop: function() {
		if (this.tid) {
			clearTimeout(this.tid);
			this.tid = null
		}
	},
	isRunning: function() {
		return (this.tid != null)
	},
	_onTimer: function() {
		this.tid = null;
		this.onTimer()
	},
	onTimer: function() {}
};

function TomatoRefresh(e, b, d, c) {
	this.setup(e, b, d, c);
	this.timer = new TomatoTimer(THIS(this, this.start))
}
TomatoRefresh.prototype = {
	running: 0,
	setup: function(g, b, f, d) {
		var h, c;
		this.actionURL = g;
		this.postData = b;
		this.refreshTime = f * 1000;
		this.cookieTag = d
	},
	start: function() {
		var b;
		if ((b = E("refresh-time")) != null) {
			if (this.cookieTag) {
				cookie.set(this.cookieTag, b.value)
			}
			this.refreshTime = b.value * 1000
		}
		b = undefined;
		this.updateUI("start");
		this.running = 1;
		if ((this.http = new XmlHttp()) == null) {
			reloadPage();
			return
		}
		this.http.parent = this;
		this.http.onCompleted = function(e, c) {
			var d = this.parent;
			if (d.cookieTag) {
				cookie.unset(d.cookieTag + "-error")
			}
			if (!d.running) {
				d.stop();
				return
			}
			d.refresh(e);
			if ((d.refreshTime > 0) && (!d.once)) {
				d.updateUI("wait");
				d.timer.start(Math.round(d.refreshTime))
			} else {
				d.stop()
			}
			d.errors = 0
		};
		this.http.onError = function(c) {
			var f = this.parent;
			if ((!f) || (!f.running)) {
				return
			}
			f.timer.stop();
			if (++f.errors <= 3) {
				f.updateUI("wait");
				f.timer.start(3000);
				return
			}
			if (f.cookieTag) {
				var d = cookie.get(f.cookieTag + "-error") * 1;
				if (isNaN(d)) {
					d = 0
				} else {
					++d
				}
				cookie.unset(f.cookieTag);
				cookie.set(f.cookieTag + "-error", d, 1);
				if (d >= 3) {
					alert("XMLHTTP: " + c);
					return
				}
			}
			setTimeout(reloadPage, 2000)
		};
		this.errors = 0;
		this.http.post(this.actionURL, this.postData)
	},
	stop: function() {
		if (this.cookieTag) {
			cookie.set(this.cookieTag, "0")
		}
		this.running = 0;
		this.updateUI("stop");
		this.timer.stop();
		this.http = null;
		this.once = undefined
	},
	toggle: function(b) {
		if (this.running) {
			this.stop()
		} else {
			this.start(b)
		}
	},
	updateUI: function(f) {
		var d, c;
		if (typeof(E) == "undefined") {
			return
		}
		c = (f != "stop") && (this.refreshTime > 0);
		if ((d = E("refresh-button")) != null) {
			d.innerHTML = c ? '停止 <i class="icon-cancel"></i>' : '刷新 <i class="icon-refresh"></i>';
			d.disabled = ((f == "start") && (!c))
		}
		if ((d = E("refresh-time")) != null) {
			d.disabled = c
		}
		if ((d = E("refresh-spinner")) != null) {
			d.style.visibility = c ? "visible" : "hidden"
		}
	},
	initPage: function(c, d) {
		var f, b;
		f = E("refresh-time");
		if (((this.cookieTag) && (f != null)) && ((b = cookie.get(this.cookieTag)) != null) && (!isNaN(b *= 1))) {
			f.value = Math.abs(b);
			if (b > 0) {
				b = (b * 1000) + (c || 0)
			}
		} else {
			if (d) {
				b = d;
				if (f) {
					f.value = d
				}
			} else {
				b = 0
			}
		}
		if (c < 0) {
			b = -c;
			this.once = 1
		}
		if (b > 0) {
			this.running = 1;
			this.refreshTime = b;
			this.timer.start(b);
			this.updateUI("wait")
		}
	},
	destroy: function() {
		this.running = 0;
		this.updateUI("wait");
		this.timer.stop();
		this.http = null;
		this.once = undefined;
		this.refresh = null
	}
};

function genStdTimeList(j, h, g) {
	var c = [];
	var f = [0.5, 1, 2, 3, 4, 5, 10, 15, 30, 60, 120, 180, 240, 300, 10 * 60, 15 * 60, 20 * 60, 30 * 60];
	var e, d;
	if (g >= 0) {
		c.push('<select id="' + j + '"><option value=0>' + h);
		for (e = 0; e < f.length; ++e) {
			d = f[e];
			if (d < g) {
				continue
			}
			c.push("<option value=" + d + ">");
			if (d == 60) {
                c.push("1 分钟")
			} else {
				if (d > 60) {
                    c.push((d / 60) + " 分钟")
				} else {
					if (d == 1) {
                        c.push("1 秒")
					} else {
                        c.push(d + " 秒")
					}
				}
			}
		}
		c.push("</select> ")
	}
	return c.join("")
}
function genStdRefresh(e, d, b) {
	var c = '<div class="tomato-refresh form-inline input-append">';
	if (e) {
		c += '<div class="spinner spinner-small"></div>'
	}
	c += genStdTimeList("refresh-time", "自动刷新", d);
	c += '<button value="刷新" onclick="' + (b ? b : "refreshClick()") + '; return false;" id="refresh-button" class="btn">刷新 <i class="icon-refresh"></i></button></div>';
	return c
}
function _tabCreate(d) {
	var b = [];
	b.push('<div id="tabs" class="btn-group">');
	for (var c = 0; c < arguments.length; ++c) {
		b.push('<a class="btn btn-tab" style="border-radius: 0;" href="javascript:tabSelect(\'' + arguments[c][0] + '\')" id="' + arguments[c][0] + '">' + arguments[c][1] + "</a>")
	}
	b.push("</div>");
	return b.join("")
}
function tabCreate(b) {
	return (_tabCreate.apply(this, arguments))
}
function tabHigh(d) {
	var b = E("tabs").getElementsByTagName("A");
	for (var c = 0; c < b.length; ++c) {
		if (d != b[c].id) {
			elem.removeClass(b[c], "active")
		}
	}
	elem.addClass(d, "active")
}
var cookie = {
	set: function(b, c, d) {
		document.cookie = "tomato_" + encodeURIComponent(b) + "=" + encodeURIComponent(c) + "; expires=" + new Date(2147483647000).toUTCString() + "; path=/"
	},
	get: function(b) {
		var c = ("; " + document.cookie + ";").match("; tomato_" + encodeURIComponent(b) + "=(.*?);");
		return c ? decodeURIComponent(c[1]) : null
	},
	unset: function(b) {
		document.cookie = "tomato_" + encodeURIComponent(b) + "=; expires=" + (new Date(1)).toUTCString() + "; path=/"
	}
};

function checkEvent(b) {
	if (typeof(b) == "undefined") {
		b = event;
		b.target = b.srcElement;
		b.relatedTarget = b.toElement
	}
	return b
}
function W(b) {}
function E(b) {
	return (typeof(b) == "string") ? document.getElementById(b) : b
}
function PR(b) {
	return elem.parentElem(b, "TR") || elem.parentElem(b, "FIELDSET")
}
function THIS(c, b) {
	return function() {
		return b.apply(c, arguments)
	}
}
function UT(b) {
	return (typeof(b) == "undefined") ? "" : "" + b
}
function escapeHTML(c) {
	function b(d) {
		return "&#" + d.charCodeAt(0) + ";"
	}
	return c.replace(/[&"'<>\r\n]/g, b)
}
function escapeCGI(b) {
	return escape(b).replace(/\+/g, "%2B")
}
function escapeD(c) {
	function b(d) {
		return "%" + d.charCodeAt(0).hex(2)
	}
	return c.replace(/[<>|%]/g, b)
}
function ellipsis(c, b) {
	return (c.length <= b) ? c : c.substr(0, b - 3) + "..."
}
function MIN(d, c) {
	return d < c ? d : c
}
function MAX(d, c) {
	return d > c ? d : c
}
function fixInt(e, c, b, d) {
	if (e === null) {
		return d
	}
	e *= 1;
	if (isNaN(e)) {
		return d
	}
	if (e < c) {
		return c
	}
	if (e > b) {
		return b
	}
	return e
}
function comma(c) {
	c = "" + c;
	var b = c;
	while ((c = c.replace(/(\d+)(\d{3})/g, "$1,$2")) != b) {
		b = c
	}
	return c
}
function doScaleSize(d, c) {
	if (isNaN(d *= 1)) {
		return "-"
	}
	if (d <= 9999) {
		return "" + d
	}
	var b = -1;
	do {
		d /= 1024;++b
	} while ((d > 9999) && (b < 2));
	return comma(d.toFixed(2)) + (c ? "<small> " : " ") + (["KB", "MB", "GB"])[b] + (c ? "</small>" : "")
}
function scaleSize(b) {
	return doScaleSize(b, 1)
}
function timeString(c) {
	var b = Math.floor(c / 60);
	if ((new Date(2000, 0, 1, 23, 0, 0, 0)).toLocaleString().indexOf("23") != -1) {
		return b + ":" + (c % 60).pad(2)
	}
	return ((b == 0) ? 12 : ((b > 12) ? b - 12 : b)) + ":" + (c % 60).pad(2) + ((b >= 12) ? " PM" : " AM")
}
function features(d) {
	var c = ["ses", "brau", "aoss", "wham", "hpamp", "!nve", "11n", "1000et", "11ac"];
	var b;
	for (b = c.length - 1; b >= 0; --b) {
		if (c[b] == d) {
			return (parseInt(nvram.t_features) & (1 << b)) != 0
		}
	}
	return 0
}
function get_config(b, c) {
	return ((typeof(nvram) != "undefined") && (typeof(nvram[b]) != "undefined")) ? nvram[b] : c
}
function nothing() {}
function show_notice1(c, b) {
	if (c.length) {
		$("#ajaxwrap").prepend('<div class="alert ' + ((b == null) ? "alert-warning" : b) + '"><a href="#" class="close"><i class="icon-cancel"></i></a>' + c.replace(/\n/g, "<br>") + "</div>")
	}
}
function myName() {
	var b, c;
	b = window.location.hash.replace("#", "");
	b = b.replace(/\\/g, "/");
	if ((c = b.lastIndexOf("/")) != -1) {
		b = b.substring(c + 1, b.length)
	}
	if (b == "") {
		b = "status-overview.asp"
	}
	return "/#" + b
}
function navi_icons(b) {
	switch (b) {
	case "状态":
		return "home";
		break;
	case "基本设置":
		return "hammer";
		break;
	case "高级设置":
		return "shield";
		break;
	case "端口转发":
		return "forward";
		break;
	case "QOS设置":
		return "gauge";
		break;
	case "USB/NAS":
		return "drive";
		break;
    case "Web服务":
		return "cloud";
		break;
	case "VPN":
		return "globe";
		break;
    case "系统管理":
		return "wrench";
		break;
	default:
		return "plus";
		break
	}
}
function navi() {
	var b = "";
	var f = window.location.hash || location.hash;
	var d = {
        "系统状态": {
            "状态概览": "status-home.asp",
            "联机设备": "status-devices.asp",
            "网站记录": "status-webmon.asp",
            "日志信息": "status-log.asp"
        },
        "基本设置": {
            "网络设置": "basic-network.asp",
            "IPv6设置": "basic-ipv6.asp",
            "名称设置": "basic-ident.asp",
            "时间设置": "basic-time.asp",
            "动态DNS": "basic-ddns.asp",
            "静态DHCP": "basic-static.asp",
            "无线过滤": "basic-wfilter.asp"
        },
        "高级设置": {
            "访问限制": "advanced-restrict.asp",
            "连接数/超时设置": "advanced-ctnf.asp",
            "DHCP/DNS": "advanced-dhcpdns.asp",
            "防火墙设置": "advanced-firewall.asp",
		"Adblock": "advanced-adblock.asp",
            "网络通告": "advanced-splashd.asp",
            "MAC地址设置": "advanced-mac.asp",
            "其它设置": "advanced-misc.asp",
            "路由表设置": "advanced-routing.asp",
            "多WAN设置": "advanced-pbr.asp",
            "TOR设置": "advanced-tor.asp",
            "无线设置": "advanced-wireless.asp",
            "VLAN设置": "advanced-vlan.asp",
            "LAN控制": "advanced-access.asp",
            "虚拟无线接口设置": "advanced-wlanvifs.asp"
        },
        "端口转发": {
            "IPv4转发": "forward-basic.asp",
            "IPv6转发": "forward-basic-ipv6.asp",
            "DMZ设置": "forward-dmz.asp",
            "端口触发": "forward-triggered.asp",
            "UPnP/NAT-PMP": "forward-upnp.asp"
        },
        "QOS设置": {
            "基本设置": "qos-settings.asp",
            "分类设置": "qos-classify.asp",
            "图形分析": "qos-graphs.asp",
            "链接查看": "qos-detailed.asp",
            "传输速率": "qos-ctrate.asp",
            "宽带限速": "qos-qoslimit.asp"
		},
		"VPN设置": {
            "OpenVPN服务器": "vpn-server.asp",
            "OpenVPN客户端": "vpn-client.asp",
            "PPTP服务器": "vpn-pptp-server.asp",
            "PPTP在线用户": "vpn-pptp-online.asp",
            "PPTP客户端": "vpn-pptp.asp",
		},
        "系统管理": {
            "访问设置": "admin-access.asp",
            "TomatoAnon项目": "admin-tomatoanon.asp",
            "宽带监控": "admin-bwm.asp",
            "流量监控": "admin-iptraffic.asp",
            "按钮/指示灯": "admin-buttons.asp",
            "CIFS客户端": "admin-cifs.asp",
            "备份恢复": "admin-config.asp",
            "调试": "admin-debug.asp",
	    "JFFS": "admin-jffs2.asp",
            "日志管理": "admin-log.asp",
            "定时任务": "admin-sched.asp",
            "脚本设置": "admin-scripts.asp",
	    "SNMP": "admin-snmp.asp",
	"固件升级": "admin-upgrade.asp"
		}
	};
	try {
		$.extend(true, d, JSON.parse(nvram.at_nav))
	} catch (c) {}
	if (f == null || f == "") {
		f = "#status-home.asp"
	}
	$.each(d, function(h, g) {
		var j = "";
		var e = '<i class="icon-' + navi_icons(h) + '"></i> <span class="icons-desc">' + h + "</span>";
		if (typeof(g) !== "object") {
			console.log('Navigation configuration error! The key "' + h + '" is type "' + typeof(g) + '" instead of OBJECT!');
			return
		}
		$.each(g, function(k, l) {
			if (/\//i.test(l) === false) {
				l = "#" + l
			}
			if (/http(s)?:\/\//i.test(l)) {
				l = l + '" target="_blank'
			}
			j += '<li class="' + ((f == l) ? "active" : "") + '"><a href="' + l + '">' + k + "</a></li>"
		});
		b += "<li" + (($(j).filter(".active")[0] == null) ? "" : ' class="active"') + '><a href="#">' + e + "</a><ul>" + j + "</ul></li>"
	});
	$(".navigation > ul").prepend(b)
}
function createFieldTable(h, o, u, j) {
	var p;
	var k, g;
	var b;
	var c;
	var l;
	var m;
	var r;
	var d = [];
	var e;
	var t;
	var q;
	if ((h.indexOf("noopen") == -1)) {
		d.push('<table class="' + ((typeof j != "undefined") ? j : "data-table") + '">')
	}
	for (desci = 0; desci < o.length; ++desci) {
		var s = o[desci];
		if (!s) {
			d.push("<tr><td colspan=2>&nbsp;</td></tr>");
			continue
		}
		if (s.ignore) {
			continue
		}
		d.push("<tr");
		if (s.rid) {
			d.push(' id="' + s.rid + '"')
		}
		if (s.hidden) {
			d.push(' style="display:none"')
		}
		d.push(">");
		if (s.help) {
			s.title += ' (<i class="icon-info icon-normal tooltip" data-info="' + s.help + '"></i>)'
		}
		if (s.text) {
			if (s.title) {
				d.push("<td>" + s.title + "</td><td>" + s.text + "</td></tr>")
			} else {
				d.push("<td colspan=2>" + s.text + "</td></tr>")
			}
			continue
		}
		t = "";
		e = [];
		e.push("<td>");
		if (s.multi) {
			l = s.multi
		} else {
			l = [s]
		}
		for (g = 0; g < l.length; ++g) {
			m = l[g];
			if (m.prefix) {
				e.push(m.prefix)
			}
			if ((m.type == "radio") && (!m.id)) {
				c = "_" + m.name + "_" + k
			} else {
				c = (m.id ? m.id : ("_" + m.name))
			}
			if (t == "") {
				t = c
			}
			p = ' onchange="verifyFields(this, 1)" id="' + c + '"';
			if (m.attrib) {
				p += " " + m.attrib
			}
			b = m.name ? (' name="' + m.name + '"') : "";
			switch (m.type) {
			case "checkbox":
				e.push('<input class="custom" type="checkbox"' + b + (m.value ? " checked" : "") + ' onclick="verifyFields(this, 1)"' + p + ">");
				break;
			case "radio":
				e.push('<input class="custom" type="radio"' + b + (m.value ? " checked" : "") + ' onclick="verifyFields(this, 1)"' + p + ">");
				break;
			case "password":
				if (m.peekaboo) {
					switch (get_config("web_pb", "1")) {
					case "0":
						m.type = "text";
					case "2":
						m.peekaboo = 0;
						break
					}
				}
				if (m.type == "password") {
					p += ' autocomplete="off"';
					if (m.peekaboo) {
						p += " onfocus='peekaboo(\"" + c + "\",1)'"
					}
				}
			case "text":
				e.push('<input type="' + m.type + '"' + b + ' value="' + escapeHTML(UT(m.value)) + '" maxlength=' + m.maxlen + (m.size ? (" size=" + m.size) : "") + p + ">");
				break;
			case "select":
				e.push("<select" + b + p + ">");
				for (k = 0; k < m.options.length; ++k) {
					r = m.options[k];
					if (r.length == 1) {
						r.push(r[0])
					}
					e.push('<option value="' + r[0] + '"' + ((r[0] == m.value) ? " selected" : "") + ">" + r[1] + "</option>")
				}
				e.push("</select>");
				break;
			case "textarea":
				e.push("<textarea " + (m.style ? (' style="' + m.style + '" ') : "") + b + p + (m.wrap ? (" wrap=" + m.wrap) : "") + ">" + escapeHTML(UT(m.value)) + "</textarea>");
				break;
			default:
				if (m.custom) {
					e.push(m.custom)
				}
				break
			}
			if (m.suffix) {
				e.push(m.suffix)
			}
		}
		e.push("</td>");
		d.push("<td>");
		if (t != "") {
			d.push('<label for="' + c + '">' + s.title + "</label></td>")
		} else {
			d.push(+s.title + "</td>")
		}
		d.push(e.join(""));
		d.push("</tr>")
	}
	if ((!h) || (h.indexOf("noclose") == -1)) {
		d.push("</table>")
	}
	if (u != null) {
		$(u).append(d.join(""))
	} else {
		return d.join("")
	}
}
function peekaboo(h, b) {
	try {
		var g = document.createElement("INPUT");
		var f = E(h);
		var c = f.name;
		g.type = b ? "text" : "password";
		g.value = f.value;
		g.size = f.size;
		g.maxLength = f.maxLength;
		g.autocomplete = f.autocomplete;
		g.title = f.title;
		g.disabled = f.disabled;
		g.onchange = f.onchange;
		f.parentNode.replaceChild(g, f);
		f = null;
		g.id = h;
		g.name = c;
		if (b) {
			g.onblur = function(e) {
				setTimeout('peekaboo("' + this.id + '", 0)', 0)
			};
			setTimeout('try { E("' + h + '").focus() } catch (ex) { }', 0)
		} else {
			g.onfocus = function(e) {
				peekaboo(this.id, 1)
			}
		}
	} catch (d) {}
}
function reloadPage() {
	if (document.location.hash.match(/#/)) {
		loadPage(document.location.hash)
	} else {
		loadPage("#status-home.asp")
	}
}
function reboot() {
    if (confirm("是否重启?")) {
		form.submitHidden("tomato.cgi", {
			_reboot: 1,
			_commit: 0,
			_nvset: 0
		})
	} else {
		return false
	}
}
function shutdown() {
    if (confirm("是否关机?")) {
		form.submitHidden("shutdown.cgi", {})
	} else {
		return false
	}
}
function logout() {
	form.submitHidden("logout.asp", {})
}(function(b) {
	b.fn.forms = function(d, c) {
		b(this).append(createFormFields(d, c))
	}
})(jQuery);

function createFormFields(h, f) {
	var j, e, d, b, g = "";
	var c = $.extend({
		align: "left",
		grid: ["col-sm-3", "col-sm-9"]
	}, f);
	$.each(h, function(l, k) {
		if (!k) {
			g += "<br />";
			return
		}
		if (k.ignore) {
			return
		}
		g += "<fieldset" + ((k.rid) ? ' id="' + k.rid + '"' : "") + ((k.hidden) ? ' style="display: none;"' : "") + ">";
		if (k.help) {
			k.title += ' (<i data-toggle="tooltip" class="icon-info icon-normal" title="' + k.help + '"></i>)'
		}
		if (k.text) {
			if (k.title) {
				g += '<label class="' + c.grid[0] + " " + ((c.align == "center") ? "control-label" : "control-left-label") + '">' + k.title + '</label><div class="' + c.grid[1] + ' text-block">' + k.text + "</div></fieldset>"
			} else {
				g += '<label class="' + c.grid[0] + " " + ((c.align == "center") ? "control-label" : "control-left-label") + '">' + k.text + "</label></fieldset>"
			}
			return
		}
		if (k.multi) {
			multiornot = k.multi
		} else {
			multiornot = [k]
		}
		b = "";
		$.each(multiornot, function(m, n) {
			if ((n.type == "radio") && (!n.id)) {
				j = "_" + n.name + "_" + i
			} else {
				j = (n.id ? n.id : ("_" + n.name))
			}
			if (e == "") {
				e = j
			}
			d = ' onchange="verifyFields(this, 1)" id="' + j + '"';
			if (n.size > 65) {
				d += ' style="width: 100%; display: block;"'
			}
			if (n.attrib) {
				d += " " + n.attrib
			}
			name = n.name ? (' name="' + n.name + '"') : "";
			if (n.prefix) {
				b += n.prefix
			}
			switch (n.type) {
			case "checkbox":
                b += '<div class="checkbox c-checkbox"><label><input class="自定义" type="checkbox"' + name + (n.value ? " checked": "") + ' onclick="verifyFields(this, 1)"' + d + "><span></span> " + (n.suffix ? n.suffix: "") + "</label></div>";
				break;
			case "radio":
                b += '<div class="radio c-radio"><label><input class="自定义" type="radio"' + name + (n.value ? " checked": "") + ' onclick="verifyFields(this, 1)"' + d + "><span></span> " + (n.suffix ? n.suffix: "") + "</label></div>";
				break;
			case "password":
				if (n.peekaboo) {
					switch (get_config("web_pb", "1")) {
					case "0":
						n.type = "text";
					case "2":
						n.peekaboo = 0;
						break
					}
				}
				if (n.type == "password") {
					d += ' autocomplete="off"';
					if (n.peekaboo) {
						d += " onfocus='peekaboo(\"" + j + "\",1)'"
					}
				}
			case "text":
				b += '<input type="' + n.type + '"' + name + ' value="' + escapeHTML(UT(n.value)) + '" maxlength=' + n.maxlen + (n.size ? (" size=" + n.size) : "") + d + ">";
				break;
			case "select":
				b += "<select" + name + d + ">";
				for (optsCount = 0; optsCount < n.options.length; ++optsCount) {
					a = n.options[optsCount];
					if (a.length == 1) {
						a.push(a[0])
					}
					b += '<option value="' + a[0] + '"' + ((a[0] == n.value) ? " selected" : "") + ">" + a[1] + "</option>"
				}
				b += "</select>";
				break;
			case "textarea":
				b += "<textarea " + (n.style ? (' style="' + n.style + '" ') : "") + name + d + (n.wrap ? (" wrap=" + n.wrap) : "") + ">" + escapeHTML(UT(n.value)) + "</textarea>";
				break;
			default:
				if (n.custom) {
					b += n.custom
				}
				break
			}
			if (n.suffix && (n.type != "checkbox" && n.type != "radio")) {
				b += '<span class="help-block">' + n.suffix + "</span>"
			}
		});
		if (e != "") {
			g += '<label class="' + c.grid[0] + " " + ((c.align == "center") ? "control-label" : "control-left-label") + '" for="' + j + '">' + k.title + '</label><div class="' + c.grid[1] + '">' + b
		} else {
			g += "<label>" + k.title + "</label>"
		}
		g += "</div></fieldset>"
	});
	return g
}
function isLocal() {
	return location.href.search("file://") == 0
};