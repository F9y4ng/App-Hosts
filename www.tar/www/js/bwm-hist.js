var months = ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"];
var snames = [" KB", " MB", " GB"];
var scale = 2;

function rescale(b, a) {
	if ((a) && (b == 0)) {
		return "-"
	}
	return (((a) && (b > 0)) ? "+" : "") + comma((b / ((scale == 2) ? 1048576 : ((scale == 1) ? 1024 : 1))).toFixed(2)) + snames[scale]
}
function changeScale(a) {
	scale = a.value * 1;
	redraw();
	save()
}
function makeRow(c, e, a, b, d) {
	return '<tr class="' + c + '"><td class="rtitle">' + e + '</td><td class="dl">' + a + '</td><td class="ul">' + b + '</td><td class="total">' + d + "</td></tr>"
}
function makeRowIP(c, e, f, a, b, d) {
	return '<tr class="' + c + '"><td class="rtitle">' + e + '</td><td class="ip">' + f + '</td><td class="dl">' + a + '</td><td class="ul">' + b + '</td><td class="total">' + d + "</td></tr>"
}
function cmpHist(d, c) {
	d = parseInt(d[0], 0);
	c = parseInt(c[0], 0);
	if (d < c) {
		return 1
	}
	if (d > c) {
		return -1
	}
	return 0
}
function checkRstats() {
	if (nvram.rstats_enable != "1") {
		W('<div class="alert alert-warning">宽带监控已禁用.</b> <a href="admin-bwm.asp">启用 &raquo;</a></div>');
		$(function() {
			E("rstats").style.display = "none"
		})
	} else {
		W('<div class="alert alert-info" style="display:none" id="rbusy">该rstats程序没有响应或正忙,试了几秒钟后重新加载.</div>')
	}
}
function checkCstats() {
	if (nvram.cstats_enable != "1") {
		W('<div class="alert alert-info">IP流量监控禁用.</b> <a href="admin-iptraffic.asp">启用 &raquo;</a></div>');
		$(function() {
			E("cstats").style.display = "none"
		})
	} else {
		if (cstats_busy) {
			W('<div class="alert alert-info">该rstats程序没有响应或正忙,试了几秒钟后重新加载.</div>')
		}
	}
}
var dateFormat = -1;

function ymText(a, b) {
	switch (dateFormat) {
	case 1:
		return (b + 1).pad(2) + "-" + a;
	case 2:
		return months[b] + " " + a;
	case 3:
		return (b + 1).pad(2) + "." + a
	}
	return a + "-" + (b + 1).pad(2)
}
function ymdText(b, c, a) {
	switch (dateFormat) {
	case 1:
		return (c + 1) + "-" + a.pad(2) + "-" + b;
	case 2:
		return months[c] + " " + a + ", " + b;
	case 3:
		return a.pad(2) + "." + (c + 1).pad(2) + "." + b
	}
	return b + "-" + (c + 1).pad(2) + "-" + a.pad(2)
}
function changeDate(a, b) {
	dateFormat = a.value * 1;
	cookie.set(b, a.value, 31);
	redraw()
}
function initDate(a) {
	dateFormat = fixInt(cookie.get(a), 0, 3, 0);
	E("dafm").value = dateFormat
};