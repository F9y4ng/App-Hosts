function selectedBand(uidx) {
	if (bands[uidx].length > 1) {
		var u = wl_fface(uidx);
		var e = E("_f_wl" + u + "_nband");
		return (e.value + "" == "" ? eval('nvram["wl' + u + '_nband"]') : e.value)
	} else {
		if (bands[uidx].length > 0) {
			return bands[uidx][0][0] || "0"
		} else {
			return "0"
		}
	}
}
function refreshNetModes(uidx) {
	var e, i, buf, val;
	if (uidx >= wl_ifaces.length) {
		return
	}
	var u = wl_unit(uidx);
	var m = [
		["mixed", "自动"]
	];
	if (selectedBand(uidx) == "1") {
		m.push(["a-only", "仅 802.11a"]);
		if (nphy) {
			m.push(["n-only", "仅 802.11n"])
		}
	} else {
		m.push(["b-only", "仅 802.11b"]);
		m.push(["g-only", "仅 802.11g"]);
		if (nphy) {
			m.push(["bg-mixed", "802.11 b/g"]);
			m.push(["n-only", "仅 802.11n"])
		}
	}
	e = E("_wl" + u + "_net_mode");
	buf = "";
	val = (!nm_loaded[uidx] || (e.value + "" == "")) ? eval('nvram["wl' + u + '_net_mode"]') : e.value;
	if (val == "disabled") {
		val = "mixed"
	}
	for (i = 0; i < m.length; ++i) {
		buf += '<option value="' + m[i][0] + '"' + ((m[i][0] == val) ? " selected" : "") + ">" + m[i][1] + "</option>"
	}
	e = E("__wl" + u + "_net_mode");
	buf = '<select name="wl' + u + '_net_mode" onchange="verifyFields(this, 1)" id = "_wl' + u + '_net_mode">' + buf + "</select>";
	elem.setInnerHTML(e, buf);
	nm_loaded[uidx] = 1
}
function refreshChannels(uidx) {
	if (refresher[uidx] != null) {
		return
	}
	if (u >= wl_ifaces.length) {
		return
	}
	var u = wl_unit(uidx);
	refresher[uidx] = new XmlHttp();
	refresher[uidx].onCompleted = function(text, xml) {
		try {
			var e, i, buf, val;
			var wl_channels = [];
			eval(text);
			ghz[uidx] = [];
			max_channel[uidx] = 0;
			for (i = 0; i < wl_channels.length; ++i) {
				ghz[uidx].push([wl_channels[i][0] + "", (wl_channels[i][0]) ? ((wl_channels[i][1]) ? wl_channels[i][0] + " - " + (wl_channels[i][1] / 1000).toFixed(3) + " GHz" : wl_channels[i][0] + "") : "Auto"]);
				max_channel[uidx] = wl_channels[i][0] * 1
			}
			e = E("_wl" + u + "_channel");
			buf = "";
			val = (!ch_loaded[uidx] || (e.value + "" == "")) ? eval('nvram["wl' + u + '_channel"]') : e.value;
			for (i = 0; i < ghz[uidx].length; ++i) {
				buf += '<option value="' + ghz[uidx][i][0] + '"' + ((ghz[uidx][i][0] == val) ? " selected" : "") + ">" + ghz[uidx][i][1] + "</option>"
			}
			e = E("__wl" + u + "_channel");
			buf = '<select name="wl' + u + '_channel" onchange="verifyFields(this, 1)" id = "_wl' + u + '_channel">' + buf + "</select>";
			elem.setInnerHTML(e, buf);
			ch_loaded[uidx] = 1;
			refresher[uidx] = null;
			verifyFields(null, 1)
		} catch (x) {}
		refresher[uidx] = null
	};
	var bw, sb, e;
	e = E("_f_wl" + u + "_nctrlsb");
	if (e != null) {
		sb = (e.value + "" == "" ? eval('nvram["wl' + u + '_nctrlsb"]') : e.value);
		e = E("_wl" + u + "_nbw_cap");
		bw = (e.value + "" == "" ? eval('nvram["wl' + u + '_nbw_cap"]') : e.value) == "0" ? "20" : "40";
		refresher[uidx].onError = function(ex) {
			alert(ex);
			refresher[uidx] = null;
			reloadPage()
		};
		refresher[uidx].post("update.cgi", "exec=wlchannels&arg0=" + u + "&arg1=" + (nphy ? "1" : "0") + "&arg2=" + bw + "&arg3=" + selectedBand(uidx) + "&arg4=" + sb)
	}
}
function scan() {
	if (xob) {
		return
	}
	var unit = wscan.unit;
	var uidx = wl_uidx(unit);
	xob = new XmlHttp();
	xob.onCompleted = function(text, xml) {
		try {
			var i;
			wlscandata = [];
			eval(text);
			for (i = 0; i < wlscandata.length; ++i) {
				var data = wlscandata[i];
				var ch = data[2];
				var mac = data[0];
				if (!wscan.inuse[ch]) {
					wscan.inuse[ch] = {
						count: 0,
						rssi: -999,
						ssid: ""
					}
				}
				if (!wscan.seen[mac]) {
					wscan.seen[mac] = 1;
					++wscan.inuse[ch].count
				}
				if (data[4] > wscan.inuse[ch].rssi) {
					wscan.inuse[ch].rssi = data[4];
					wscan.inuse[ch].ssid = data[1]
				}
			}
			var e = E("_wl" + unit + "_channel");
			for (i = 1; i < ghz[uidx].length; ++i) {
				var s = ghz[uidx][i][1];
				var u = wscan.inuse[ghz[uidx][i][0]];
				if (u) {
					s += " (" + u.count + " AP" + (u.count == 1 ? "" : "s") + ' / 最强: "' + escapeHTML(ellipsis(u.ssid, 15)) + '" ' + u.rssi + " dBm)"
				}
				e.options[i].innerHTML = s
			}
			e.style.width = "400px";
			xob = null;
			if (wscan.tries < 4) {
				++wscan.tries;
				setTimeout(scan, 1000);
				return
			}
		} catch (x) {}
		spin(0, unit)
	};
	xob.onError = function(x) {
		alert("error: " + x);
		spin(0, unit);
		xob = null
	};
	spin(1, unit);
	xob.post("update.cgi", "exec=wlscan&arg0=" + unit)
}
function scanButton(a) {
	if (xob) {
		return
	}
	wscan = {
		unit: a,
		seen: [],
		inuse: [],
		tries: 0
	};
	scan()
}
function joinAddr(b) {
	var e, c, d;
	e = [];
	for (c = 0; c < b.length; ++c) {
		d = b[c];
		if ((d != "00:00:00:00:00:00") && (d != "0.0.0.0")) {
			e.push(d)
		}
	}
	return e.join(" ")
}
function random_x(a) {
	var d = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	var b = "";
	while (a-- > 0) {
		b += d.substr(Math.floor(d.length * Math.random()), 1)
	}
	return b
}
function random_psk(b) {
	var a = E(b);
	a.value = random_x(63);
	verifyFields(null, 1)
}
function random_wep(a) {
	E("_wl" + a + "_passphrase").value = random_x(16);
	generate_wep(a)
}
function v_wep(c, a) {
	var b = c.value;
	if (((b.length == 5) || (b.length == 13)) && (b.length == (c.maxLength >> 1))) {} else {
		b = b.toUpperCase().replace(/[^0-9A-F]/g, "");
		if (b.length != c.maxLength) {
			ferror.set(c, "无效WEP密钥，应该为 " + c.maxLength + " 十六进制或 " + (c.maxLength >> 1) + " ASCII字符.", a);
			return 0
		}
	}
	c.value = b;
	ferror.clear(c);
	return 1
}
function generate_wep(b) {
	function a(f, e) {
		while (f.length < 64) {
			f += f
		}
		return hex_md5(f.substr(0, 64)).substr(e, (E("_wl" + b + "_wep_bit").value == 128) ? 26 : 10)
	}
	var d = E("_wl" + b + "_passphrase");
	var c = d.value;
	if (!v_length(d, false, 3)) {
		return
	}
	E("_wl" + b + "_key1").value = a(c, 0);
	c += "#$%";
	E("_wl" + b + "_key2").value = a(c, 2);
	c += "!@#";
	E("_wl" + b + "_key3").value = a(c, 4);
	c += "%&^";
	E("_wl" + b + "_key4").value = a(c, 6);
	verifyFields(null, 1)
};